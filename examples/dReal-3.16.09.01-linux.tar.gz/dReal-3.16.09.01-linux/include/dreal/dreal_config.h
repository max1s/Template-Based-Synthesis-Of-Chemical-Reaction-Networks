#pragma once
#define USE_GLPK
#define USE_NLOPT
#define SUPPORT_ODE
#define LOGGING
#define PYTHONLIBS_FOUND
